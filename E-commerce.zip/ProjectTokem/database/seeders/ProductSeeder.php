<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Product::create([
        //     'image' => 'images/1641104667Acanthocereus.jpg',
        //     'name' => 'Acanthocereus tetragonus',
        //     'description' => 'Acanthocereus tetragonus, is a species of cactus that is native to Florida and the Lower Rio Grande Valley of Texas in the United States, Mexico, Central America, the Caribbean, and northern South America.',
        //     'price' => '25000',
        //     'stock' => '10',
        //     'category_id' => 1
        // ]);
        // Product::create([
        //     'image' => 'images/1641104667Acanthocereus.jpg',
        //     'name' => 'Adromischus cristatus',
        //     'description' => 'Adromischus cristatus is a species of succulents from the family Crassulaceae, endemic to the eastern cape of South Africa. It is a perennial with short erect branches 20–50 mm long covered with fine aerial roots.',
        //     'price' => '30000',
        //     'stock' => '5',
        //     'category_id' => 1
        // ]);
        // Product::create([
        //     'image' => 'images/1641104667Acanthocereus.jpg',
        //     'name' => 'Product 3',
        //     'description' => 'Adromischus cristatus is a species of succulents from the family Crassulaceae, endemic to the eastern cape of South Africa. It is a perennial with short erect branches 20–50 mm long covered with fine aerial roots.',
        //     'price' => '30000',
        //     'stock' => '5',
        //     'category_id' => 1
        // ]);
        // Product::create([
        //     'image' => 'images/1641104667Acanthocereus.jpg',
        //     'name' => 'Product 4',
        //     'description' => 'Adromischus cristatus is a species of succulents from the family Crassulaceae, endemic to the eastern cape of South Africa. It is a perennial with short erect branches 20–50 mm long covered with fine aerial roots.',
        //     'price' => '30000',
        //     'stock' => '5',
        //     'category_id' => 1
        // ]);
        // Product::create([
        //     'image' => 'images/1641104667Acanthocereus.jpg',
        //     'name' => 'Product 5',
        //     'description' => 'Adromischus cristatus is a species of succulents from the family Crassulaceae, endemic to the eastern cape of South Africa. It is a perennial with short erect branches 20–50 mm long covered with fine aerial roots.',
        //     'price' => '30000',
        //     'stock' => '5',
        //     'category_id' => 2
        // ]);
        // Product::create([
        //     'image' => 'images/1641104667Acanthocereus.jpg',
        //     'name' => 'Product 6',
        //     'description' => 'Adromischus cristatus is a species of succulents from the family Crassulaceae, endemic to the eastern cape of South Africa. It is a perennial with short erect branches 20–50 mm long covered with fine aerial roots.',
        //     'price' => '30000',
        //     'stock' => '5',
        //     'category_id' => 2
        // ]);
        // Product::create([
        //     'image' => 'images/1641104667Acanthocereus.jpg',
        //     'name' => 'Product 7',
        //     'description' => 'Adromischus cristatus is a species of succulents from the family Crassulaceae, endemic to the eastern cape of South Africa. It is a perennial with short erect branches 20–50 mm long covered with fine aerial roots.',
        //     'price' => '30000',
        //     'stock' => '5',
        //     'category_id' => 2
        // ]);
        // Product::create([
        //     'image' => 'images/1641104667Acanthocereus.jpg',
        //     'name' => 'Product 8',
        //     'description' => 'Adromischus cristatus is a species of succulents from the family Crassulaceae, endemic to the eastern cape of South Africa. It is a perennial with short erect branches 20–50 mm long covered with fine aerial roots.',
        //     'price' => '30000',
        //     'stock' => '5',
        //     'category_id' => 2
        // ]);
    }
}
