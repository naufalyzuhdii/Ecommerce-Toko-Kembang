

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="css/signup.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="logincontent">
        <h1>Sign Up</h1>

        <form action="/signup" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" name="name" placeholder="Name">
            <input type="email" name="email" placeholder="Email">
            <input type="password" name="password" placeholder="Password">
            <input type="text" name="address" placeholder="Address">
            <input type="text" name="phone" placeholder="Phone">

            <input type="submit" value="Sign Up" id="loginbtn">
            
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/login/signup.blade.php ENDPATH**/ ?>