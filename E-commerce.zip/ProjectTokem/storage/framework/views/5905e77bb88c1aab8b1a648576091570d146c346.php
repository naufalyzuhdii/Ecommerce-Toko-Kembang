

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="css/profile.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="profile-page">
        <h1 class="page-title">My Profile</h1>
        <form action="<?php echo e(route('user.update')); ?>" method="post">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="profile-content">
                <input type="text" name="name" id="name" value="<?php echo e(old('name', Auth::user()->name)); ?>" placeholder="Full Name">
            </div>
            <div class="profile-content">
                <input type="email" name="email" id="email" value="<?php echo e(old('email', Auth::user()->email)); ?>" placeholder="Email">
            </div>
            <div class="profile-content">
                <input type="text" name="address" id="address" value="<?php echo e(old('address', Auth::user()->address)); ?>" placeholder="Address">
            </div>
            <div class="profile-content">
                <input type="text" name="phone" id="phone" value="<?php echo e(old('phone', Auth::user()->phone)); ?>" placeholder="Phone">
            </div>
            <button class="update-button">Update</button>
        </form>    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/profile.blade.php ENDPATH**/ ?>