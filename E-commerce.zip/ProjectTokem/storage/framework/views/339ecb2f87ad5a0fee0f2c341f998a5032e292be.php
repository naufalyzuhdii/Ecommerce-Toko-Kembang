

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="products.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <h1>Our Products</h1>
    </div>
    <div class="wrap">
        <form action="/products" autocomplete="on">
            <input id="search" name="search" type="text" placeholder="What're you looking for ?"><input id="search_submit" value="Rechercher" type="submit">
        </form>
    </div>
    <div class="product-content">
        <?php if(count($products) == 0): ?>
            <div>
                <h1>No Data</h1>
            </div>
        <?php elseif(count($products) > 0): ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="detail/<?php echo e($product->id); ?>">
                    <div class="grid-container">
                        <div class="item">
                            <div class="shop-card">
                                <div class="title">
                                    <?php echo e($product->name); ?>

                                </div>
                                <div class="desc">
                                    <?php echo e($product->category->name); ?>

                                </div>
                                <div class="slider">
                                    <figure>
                                        <img src="<?php echo e(Storage::url($product->image)); ?>" width="400" height="300"/>
                                    </figure>
                                </div>
                                
                                <div class="cta">
                                    <div class="price">IDR <?php echo e($product->price); ?></div>
                                    <a href="<?php echo e(route('addtocart', ['id' => $product->id])); ?>"><button class="btn">Add to cart<span class="bg"></span></button></a>
                                </div>
                            </div>
                            <div class="bg"></div>
                        </div>
                    </div>
                </a>  
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div>
                <h1>Error</h1>
            </div>
        <?php endif; ?>
    </div>
    <div class="pagination">
        <?php echo e($products->links()); ?>    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/products.blade.php ENDPATH**/ ?>