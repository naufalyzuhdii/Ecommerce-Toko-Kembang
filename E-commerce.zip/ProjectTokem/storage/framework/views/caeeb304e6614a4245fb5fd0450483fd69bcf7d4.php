

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="css/signin.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="logincontent">
        <h1>Sign In</h1>
        <form action="/signin" method="POST">
                <?php echo csrf_field(); ?>
                <input type="email" name="email" id="email" placeholder="Email" value="<?php echo e(Cookie::get('mycookie') != null ? Cookie::get('mycookie') : ''); ?>">
                <input type="password" name="password" id="password" placeholder="Password">
                
                <div class="remembercontent">
                    <input type="checkbox" class="checkbox" name="remember" id="remember" <?php echo e(Cookie::get('mycookie') != null ? 'checked' : ''); ?> checked="checked">
                    <span id="rememberme">Remember me</span>    
                </div>

                <input type="submit" value="Sign In" id="loginbtn">
            </form>    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/login/signin.blade.php ENDPATH**/ ?>