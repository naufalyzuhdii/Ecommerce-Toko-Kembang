<nav class="membernav">
    <div class="brand">
        <a href="/member">
            <h3>Tokem</h3>    
        </a>
    </div>
    <div class="midnav">
        <a href="/about">About Us</a>
        <a href="/products">Products</a>
        <a href="">My Transaction</a>
    </div>
    <div class="profile">
        <a href="<?php echo e(route('shoppingCart')); ?>">
            <i class="fa fa-shopping-cart" style="color: white; font-size: 30px"></i>
            <span><?php echo e(Session::has('cart') ? Session::get('cart')->totalQty : ''); ?></span>
        </a>
        <a href="<?php echo e(route('user.edit')); ?>">
            <i class='far fa-user-circle'></i>
            <?php echo e(old('name', Auth::user()->name)); ?>

        </a>
    </div>
</nav><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/navbar/membernav.blade.php ENDPATH**/ ?>