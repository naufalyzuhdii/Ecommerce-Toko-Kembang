

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="css/addproduct.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <table class="product-table">
            <thead>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Category</th>
                <th>Description</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Delete</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><img src="<?php echo e(Storage::url($product->image)); ?>" alt="<?php echo e($product->name); ?>" width="200" height="200"></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->category->name); ?></td>
                        <td><?php echo e($product->description); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->stock); ?></td>
                        <td>
                            <form action="/product/<?php echo e($product->id); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="submit" value="Delete">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div>
        <h3>Insert Product</h3>
        <form action="/product" enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>

            <label for="category">Category</label>
            <select name="category" id="category">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
            </select>
            

            <label for="productImage">Image</label>
            <input type="file" name="image" id="productImage">

            <label for="productName">Name</label>
            <input type="text" name="name" id="productName">

            <label for="productDescription">Description</label>
            <input type="text" name="description" id="productDescription">

            <label for="productPrice">Price</label>
            <input type="number" name="price" id="productPrice">

            <label for="productStock">Stock</label>
            <input type="number" name="stock" id="productStock">

            <input type="submit" value="Insert">
        </form>
        <label for="error" style="color:red">
            <?php if($errors->any()): ?>
                <?php echo e($errors->first()); ?>

            <?php endif; ?>
        </label>
    </div> 
    <a href="/updateproduct">
        <button>Update</button>    
    </a>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('page.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/addproduct.blade.php ENDPATH**/ ?>