

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('cart')): ?>
    <div class="cart-content">
        <div class="tbl-header">
            <table cellpadding="0" cellspacing="0" border="0">
            <thead>
                <tr>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Price</th>
                </tr>
            </thead>
            </table>
        </div>
        <div class="tbl-content">
            <table cellpadding="0" cellspacing="0" border="0">
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($product['item']['name']); ?></td>
                    <td><?php echo e($product['qty']); ?></td>
                    <td>IDR <?php echo e($product['price']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div> 
        <div class="center">
            <input type="checkbox" id="show">
            <label for="show" class="checkout-button"><a>View Price</a></label>
            <div class="checkout-content">
                <div class="checkout-title">
                    <h1>Price</h1>
                </div>
                <div class="checkout-price">
                    <p>IDR <?php echo e($totalPrice); ?></p>
                </div>
                <div class="final-checkout-button">
                    <form action="<?php echo e(route('checkout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit">CHECKOUT</button>
                    </form>
                </div>
            </div>
        </div>    
    </div>
        
    <?php else: ?>
        <h2>No items in Cart!</h2>
    <?php endif; ?>

    <script>
        $(window).on("load resize ", function() {
            var scrollWidth = $('.tbl-content').width() - $('.tbl-content table').width();
            $('.tbl-header').css({'padding-right':scrollWidth});
        }).resize();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/cart.blade.php ENDPATH**/ ?>