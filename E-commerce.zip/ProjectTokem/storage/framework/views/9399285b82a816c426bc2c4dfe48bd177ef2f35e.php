

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="">
            <h1>Checkout</h1>
            <h4>Total: IDR <?php echo e($total); ?></h4>
            <form action="<?php echo e(route('checkout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <p>please enter the following passcode to checkout: </p>
                <button type="submit">CHECKOUT</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/checkout.blade.php ENDPATH**/ ?>