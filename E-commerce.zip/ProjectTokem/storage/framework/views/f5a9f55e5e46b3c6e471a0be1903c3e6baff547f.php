

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="css/addcategory.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <table style="border-collapse: collapse">
            <thead>
                <th>ID</th>
                <th>Category</th>
                <th>Delete</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td>
                            <form action="/category/<?php echo e($category->id); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="submit" value="Delete">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div>
        <h3>Insert Category</h3>
        <form action="/category" method="POST">
            <?php echo csrf_field(); ?>
            <label for="categoryName">Name</label>
            <input type="text" name="name" id="categoryName">
            <input type="submit" value="Insert">
        </form>
    </div>    
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('page.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/addcategory.blade.php ENDPATH**/ ?>