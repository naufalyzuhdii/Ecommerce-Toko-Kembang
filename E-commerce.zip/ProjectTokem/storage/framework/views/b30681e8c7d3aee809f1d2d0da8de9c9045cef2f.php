

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="css/homelayout.css">
    <link rel="stylesheet" href="css/authhome.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('home.homelayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="logout">
        <?php if(auth()->guard()->check()): ?>
            <form action="/logout" method="GET">
                <?php echo csrf_field(); ?>
                <input id="logout" type="submit" value="Logout">
            </form>
        <?php endif; ?>    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/home/memberhome.blade.php ENDPATH**/ ?>