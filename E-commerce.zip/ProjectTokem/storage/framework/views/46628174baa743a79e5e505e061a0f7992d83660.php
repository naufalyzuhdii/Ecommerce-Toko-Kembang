

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="css/manageproduct.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="page-title">Manage Product</h1>
    <div class="manageproduct-content">
        <a href="/addcategory">
            <div class="manage-menu">
                <div class="box">
                    <img src="MP2.jpg" alt="" width="400" height="300">
                    <div class="overlay">
                        <h1>Add Category</h1>
                    </div>
                </div>
            </div>    
        </a>
        <a href="/addproduct">
            <div class="manage-menu">
                <div class="box">
                    <img src="MP1.jpg" alt="" width="400" height="300">
                    <div class="overlay">
                        <h1>Add Product</h1>
                    </div>
                </div>
            </div>     
        </a>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/manageproduct.blade.php ENDPATH**/ ?>