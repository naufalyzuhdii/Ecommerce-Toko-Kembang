<nav class="adminnav">
    <div class="brand">
        <a href="/admin">
            <h3>Tokem</h3>    
        </a>
    </div>
    <div class="midnav">
        <a href="/about">About Us</a>
        <a href="/products">Products</a>
        <a href="/manage-product">Manage Products</a>
    </div>
    <div class="profile">
        <a href="">
            <?php if(Session::get('mysession')): ?>
               <p>Admin <?php echo e(Session::get('mysession')); ?></p>
            <?php endif; ?>
        </a>
    </div>
</nav><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/navbar/adminnav.blade.php ENDPATH**/ ?>