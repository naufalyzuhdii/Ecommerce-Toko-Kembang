

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="css/about.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ceoquote">
        <div class="text">
            <h3>"Toko Kembang grew from our love for flower and to spread the love<br>
                in our community, we started off from street vendor near Rawa<br>
                Belong street and now we have the most diverse collection for plants<br>
                and we provide professional installation and ongoing maintenance of<br>
                your live plants."
            </h3>
            <div class="footerquote">
                <p id="ceoname">Nanda ria / <span id="ceoof">CEO, Tokem</span></p>
            </div>    
        </div>
    </div>
    <div class="footcontent">
        <div class="content-1">
            <div class="title">
                <h1>Get in touch</h1>
            </div>
            <div class="aboutcontent">
                <label>
                    <input type="checkbox" />
                    <div class="card">
                        <div class="front">Sales Inquiry</div>
                        <div class="back">
                            sales@tokem.com | +62 (021) 840-7279 ext 1
                        </div>
                    </div>
                </label>
                <label>
                    <input type="checkbox" />
                    <div class="card">
                        <div class="front">Customer Service</div>
                        <div class="back">
                            cs@tokem.com | +62 (021) 840-7279 ext 9
                        </div>
                    </div>
                </label>
                <label>
                    <input type="checkbox"/>
                    <div class="card">
                        <div class="front">B2B</div>
                        <div class="back">
                            b2b@tokem.com | +62(021) 840-7279 ext 6
                        </div>
                    </div>
                </label>
            </div>
        </div>
        <div class="content-2">
            <div class="title">
                <h1>Locations</h1>
            </div>
            <div class="aboutcontent">
                <label>
                    <input type="checkbox" />
                    <div class="card">
                        <div class="front">jakarta</div>
                        <div class="back">
                            Jl. Rawa Belong No.420 | 11420
                        </div>
                    </div>
                </label>
                <label>
                    <input type="checkbox" />
                    <div class="card">
                        <div class="front">Bandung</div>
                        <div class="back">
                            Jl. Dr. Setiabudi No.269 | 40154
                        </div>
                    </div>
                </label>
                <label>
                    <input type="checkbox"/>
                    <div class="card">
                        <div class="front">Karawang</div>
                        <div class="back">
                            Jl. Belakang Pasar No.14 | 41311
                        </div>
                    </div>
                </label>
                <label>
                    <input type="checkbox"/>
                    <div class="card">
                        <div class="front">Surabaya</div>
                        <div class="back">
                            Jl. Ngagel No.173 | 60246
                        </div>
                    </div>
                </label>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/about.blade.php ENDPATH**/ ?>