<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <?php if(Auth::check()): ?>
        <?php if(Auth::user()->role=='member'): ?> <link rel="stylesheet" href="<?php echo e(asset('css/membernav.css')); ?>">
        <?php elseif(Auth::user()->role=='admin'): ?> <link rel="stylesheet" href="<?php echo e(asset('css/adminnav.css')); ?>">
        <?php endif; ?>
    <?php else: ?> <link rel="stylesheet" href="<?php echo e(asset('css/guestnav.css')); ?>">
    <?php endif; ?>
    <?php echo $__env->yieldContent('linkCSS'); ?>
    <title>Document</title>
</head>
<body>
    <?php if(Auth::check()): ?>
        <?php if(Auth::user()->role=='member'): ?> <?php echo $__env->make('navbar.membernav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif(Auth::user()->role=='admin'): ?> <?php echo $__env->make('navbar.adminnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php else: ?> <?php echo $__env->make('navbar.guestnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>
</html><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/main.blade.php ENDPATH**/ ?>