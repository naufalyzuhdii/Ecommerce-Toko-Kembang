

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/productdetail.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="product">
            <div class="product-photo">
                <img src="<?php echo e(Storage::url($product->image)); ?>">
            </div>
            <div class="product-detail">
                <h1 class="product__title"><?php echo e($product->name); ?></h1>
                <div class="product__category"><?php echo e($product->category->name); ?></div>
                <div class="product__description"><?php echo e($product->description); ?></div>
                <div class="product__footer">
                    <div class="product__price">
                        <div class="block">
                            Price : IDR <?php echo e($product->price); ?>

                        </div>
                    </div>
                    <div class="product__stock">
                        <div class="block">
                            Stock : <?php echo e($product->stock); ?>

                        </div>
                    </div>
                </div>
                <a class="product__button" href="<?php echo e(route('addtocart', ['id' => $product->id])); ?>" onClick="buttonAnimate()">
                    <span>Add to cart</span>
                    <span>Success</span>
                </a>
            </div>
        </div>
    </div>

    <script>
        const button = document.querySelector('.product__button');
        function buttonAnimate(){
            button.classList.add('product__button--success');
        }
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/productdetail.blade.php ENDPATH**/ ?>