

<?php $__env->startSection('content'); ?>
    <h1>Home Page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LAB\Project\ProjectTokem\resources\views/page/home.blade.php ENDPATH**/ ?>