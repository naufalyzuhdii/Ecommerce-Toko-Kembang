<nav class="membernav">
    <div class="brand">
        <a href="/member">
            <h3>Tokem</h3>    
        </a>
    </div>
    <div class="midnav">
        <a href="/about">About Us</a>
        <a href="/products">Products</a>
        <a href="">My Transaction</a>
    </div>
    <div class="profile">
        <a href="{{ route('shoppingCart') }}">
            <i class="fa fa-shopping-cart" style="color: white; font-size: 30px"></i>
            <span>{{ Session::has('cart') ? Session::get('cart')->totalQty : '' }}</span>
        </a>
        <a href="{{ route('user.edit') }}">
            <i class='far fa-user-circle'></i>
            {{ old('name', Auth::user()->name) }}
        </a>
    </div>
</nav>