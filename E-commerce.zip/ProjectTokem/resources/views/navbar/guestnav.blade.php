<nav class="guestnav">
    <div class="brand">
        <a href="/">
            <h3>Tokem</h3>    
        </a>
    </div>
    <div class="midnav">
        <a href="/about">About Us</a>
        <a href="/products">Products</a>
    </div>
    <div class="profile">
        <a id="signin" href="/signin">Sign In</a>
        <a id="signup" href="/signup">Sign Up</a>
    </div>
</nav>