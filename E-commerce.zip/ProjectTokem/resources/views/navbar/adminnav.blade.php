<nav class="adminnav">
    <div class="brand">
        <a href="/admin">
            <h3>Tokem</h3>    
        </a>
    </div>
    <div class="midnav">
        <a href="/about">About Us</a>
        <a href="/products">Products</a>
        <a href="/manage-product">Manage Products</a>
    </div>
    <div class="profile">
        <a href="">
            @if (Session::get('mysession'))
               <p>Admin {{ Session::get('mysession') }}</p>
            @endif
        </a>
    </div>
</nav>