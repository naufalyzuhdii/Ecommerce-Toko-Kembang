@extends('page/main')

@section('linkCSS')
    <link rel="stylesheet" href="css/signin.css">
@endsection

@section('content')
    <div class="logincontent">
        <h1>Sign In</h1>
        <form action="/signin" method="POST">
                @csrf
                <input type="email" name="email" id="email" placeholder="Email" value="{{ Cookie::get('mycookie') != null ? Cookie::get('mycookie') : '' }}">
                <input type="password" name="password" id="password" placeholder="Password">
                
                <div class="remembercontent">
                    <input type="checkbox" class="checkbox" name="remember" id="remember" {{ Cookie::get('mycookie') != null ? 'checked' : '' }} checked="checked">
                    <span id="rememberme">Remember me</span>    
                </div>

                <input type="submit" value="Sign In" id="loginbtn">
            </form>    
    </div>
@endsection