@extends('page/main')

@section('linkCSS')
    <link rel="stylesheet" href="{{ asset('css/cart.css') }}">
@endsection

@section('content')
    @if (Session::has('cart'))
    <div class="cart-content">
        <div class="tbl-header">
            <table cellpadding="0" cellspacing="0" border="0">
            <thead>
                <tr>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Price</th>
                </tr>
            </thead>
            </table>
        </div>
        <div class="tbl-content">
            <table cellpadding="0" cellspacing="0" border="0">
            <tbody>
                @foreach ($products as $product)
                    <tr>
                    <td>{{ $product['item']['name'] }}</td>
                    <td>{{ $product['qty'] }}</td>
                    <td>IDR {{ $product['price'] }}</td>
                    </tr>
                @endforeach
            </tbody>
            </table>
        </div> 
        <div class="center">
            <input type="checkbox" id="show">
            <label for="show" class="checkout-button"><a>View Price</a></label>
            <div class="checkout-content">
                <div class="checkout-title">
                    <h1>Price</h1>
                </div>
                <div class="checkout-price">
                    <p>IDR {{ $totalPrice }}</p>
                </div>
                <div class="final-checkout-button">
                    <form action="{{ route('checkout') }}" method="POST">
                        @csrf
                        <button type="submit">CHECKOUT</button>
                    </form>
                </div>
            </div>
        </div>    
    </div>
        
    @else
        <h2>No items in Cart!</h2>
    @endif

    <script>
        $(window).on("load resize ", function() {
            var scrollWidth = $('.tbl-content').width() - $('.tbl-content table').width();
            $('.tbl-header').css({'padding-right':scrollWidth});
        }).resize();
    </script>
@endsection