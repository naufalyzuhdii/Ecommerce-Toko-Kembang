@extends('page/main')

@section('linkCSS')
    <link rel="stylesheet" href="{{ asset('css/productdetail.css') }}">
@endsection

@section('content')
    <div class="container">
        <div class="product">
            <div class="product-photo">
                <img src="{{ Storage::url($product->image) }}">
            </div>
            <div class="product-detail">
                <h1 class="product__title">{{ $product->name }}</h1>
                <div class="product__category">{{ $product->category->name }}</div>
                <div class="product__description">{{ $product->description }}</div>
                <div class="product__footer">
                    <div class="product__price">
                        <div class="block">
                            Price : IDR {{ $product->price }}
                        </div>
                    </div>
                    <div class="product__stock">
                        <div class="block">
                            Stock : {{ $product->stock }}
                        </div>
                    </div>
                </div>
                <a class="product__button" href="{{ route('addtocart', ['id' => $product->id]) }}" onClick="buttonAnimate()">
                    <span>Add to cart</span>
                    <span>Success</span>
                </a>
            </div>
        </div>
    </div>

    <script>
        const button = document.querySelector('.product__button');
        function buttonAnimate(){
            button.classList.add('product__button--success');
        }
    </script>
    {{-- <div class="detail-content">
        <div class="image">
            <img src="{{ Storage::url($product->image) }}" width="500" height="400"/>
        </div>
        <div class="product-content">
            <div class="header-content">
                <div class="product-name">
                    <h2>{{ $product->name }}</h2>
                </div>
                <div class="product-category">
                    <h5>{{ $product->category->name }}</h5>
                </div>
            </div>
            <div class="mid-content">
                <div class="product-description">
                    <p>{{ $product->description }}</p>
                </div>
            </div>
        </div>
        
        <div class="product-price">
            <h4>Price : <span>IDR {{ $product->price }}</span></h4>
        </div>
        <div class="product-stock">
            <h4>Stock : <span>{{ $product->stock }}</span></h4>
        </div>
    </div>
    <a href="{{ route('addtocart', ['id' => $product->id]) }}"><button class="btn">Add to cart<span class="bg"></span></button></a> --}}
@endsection
