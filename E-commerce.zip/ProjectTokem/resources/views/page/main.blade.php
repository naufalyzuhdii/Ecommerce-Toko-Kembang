<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    @if (Auth::check())
        @if (Auth::user()->role=='member') <link rel="stylesheet" href="{{ asset('css/membernav.css') }}">
        @elseif (Auth::user()->role=='admin') <link rel="stylesheet" href="{{ asset('css/adminnav.css') }}">
        @endif
    @else <link rel="stylesheet" href="{{ asset('css/guestnav.css') }}">
    @endif
    @yield('linkCSS')
    <title>Document</title>
</head>
<body>
    @if (Auth::check())
        @if (Auth::user()->role=='member') @include('navbar.membernav')
        @elseif (Auth::user()->role=='admin') @include('navbar.adminnav')
        @endif
    @else @include('navbar.guestnav')
    @endif
    @yield('content')
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>
</html>