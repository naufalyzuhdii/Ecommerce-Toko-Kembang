@extends('page.main')

@section('linkCSS')
    <link rel="stylesheet" href="css/addproduct.css">
@endsection

@section('content')
    <div>
        <table class="product-table">
            <thead>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Category</th>
                <th>Description</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Delete</th>
            </thead>
            <tbody>
                @foreach ($products as $product)
                    <tr>
                        <td>{{ $product->id }}</td>
                        <td><img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" width="200" height="200"></td>
                        <td>{{ $product->name }}</td>
                        <td>{{ $product->category->name }}</td>
                        <td>{{ $product->description }}</td>
                        <td>{{ $product->price }}</td>
                        <td>{{ $product->stock }}</td>
                        <td>
                            <form action="/product/{{ $product->id }}" method="POST">
                                @method('DELETE')
                                @csrf
                                <input type="submit" value="Delete">
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div>
        <h3>Insert Product</h3>
        <form action="/product" enctype="multipart/form-data" method="POST">
            @csrf

            <label for="category">Category</label>
            <select name="category" id="category">
                @foreach ($categories as $category)
                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                @endforeach    
            </select>
            

            <label for="productImage">Image</label>
            <input type="file" name="image" id="productImage">

            <label for="productName">Name</label>
            <input type="text" name="name" id="productName">

            <label for="productDescription">Description</label>
            <input type="text" name="description" id="productDescription">

            <label for="productPrice">Price</label>
            <input type="number" name="price" id="productPrice">

            <label for="productStock">Stock</label>
            <input type="number" name="stock" id="productStock">

            <input type="submit" value="Insert">
        </form>
        <label for="error" style="color:red">
            @if ($errors->any())
                {{ $errors->first() }}
            @endif
        </label>
    </div> 
    <a href="/updateproduct">
        <button>Update</button>    
    </a>
@endsection
    