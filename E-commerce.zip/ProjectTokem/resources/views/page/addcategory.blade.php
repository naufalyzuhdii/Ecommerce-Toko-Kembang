@extends('page.main')

@section('linkCSS')
    <link rel="stylesheet" href="css/addcategory.css">
@endsection

@section('content')
    <div>
        <table style="border-collapse: collapse">
            <thead>
                <th>ID</th>
                <th>Category</th>
                <th>Delete</th>
            </thead>
            <tbody>
                @foreach ($categories as $category)
                    <tr>
                        <td>{{ $category->id }}</td>
                        <td>{{ $category->name }}</td>
                        <td>
                            <form action="/category/{{ $category->id }}" method="POST">
                                @method('DELETE')
                                @csrf
                                <input type="submit" value="Delete">
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div>
        <h3>Insert Category</h3>
        <form action="/category" method="POST">
            @csrf
            <label for="categoryName">Name</label>
            <input type="text" name="name" id="categoryName">
            <input type="submit" value="Insert">
        </form>
    </div>    
@endsection
    