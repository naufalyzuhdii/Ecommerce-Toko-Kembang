@extends('page/main')

@section('linkCSS')
    <link rel="stylesheet" href="products.css">
@endsection

@section('content')
    <div class="page-title">
        <h1>Our Products</h1>
    </div>
    <div class="wrap">
        <form action="/products" autocomplete="on">
            <input id="search" name="search" type="text" placeholder="What're you looking for ?"><input id="search_submit" value="Rechercher" type="submit">
        </form>
    </div>
    <div class="product-content">
        @if (count($products) == 0)
            <div>
                <h1>No Data</h1>
            </div>
        @elseif (count($products) > 0)
            @foreach ($products as $product)
                <a href="detail/{{ $product->id }}">
                    <div class="grid-container">
                        <div class="item">
                            <div class="shop-card">
                                <div class="title">
                                    {{ $product->name }}
                                </div>
                                <div class="desc">
                                    {{ $product->category->name }}
                                </div>
                                <div class="slider">
                                    <figure>
                                        <img src="{{ Storage::url($product->image) }}" width="400" height="300"/>
                                    </figure>
                                </div>
                                
                                <div class="cta">
                                    <div class="price">IDR {{ $product->price }}</div>
                                    <a href="{{ route('addtocart', ['id' => $product->id]) }}"><button class="btn">Add to cart<span class="bg"></span></button></a>
                                </div>
                            </div>
                            <div class="bg"></div>
                        </div>
                    </div>
                </a>  
                
            @endforeach
        @else
            <div>
                <h1>Error</h1>
            </div>
        @endif
    </div>
    <div class="pagination">
        {{ $products->links() }}    
    </div>
@endsection