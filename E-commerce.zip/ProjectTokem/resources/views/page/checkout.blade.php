@extends('page/main')

@section('content')
    <div class="">
        <div class="">
            <h1>Checkout</h1>
            <h4>Total: IDR {{ $total }}</h4>
            <form action="{{ route('checkout') }}" method="POST">
                @csrf
                <p>please enter the following passcode to checkout: </p>
                <button type="submit">CHECKOUT</button>
            </form>
        </div>
    </div>
@endsection