@extends('page/main')

@section('linkCSS')
    <link rel="stylesheet" href="css/homelayout.css">
@endsection

@section('content')
    @include('home.homelayout')
@endsection