@extends('page.main')

@section('linkCSS')
    <link rel="stylesheet" href="css/homelayout.css">
    <link rel="stylesheet" href="css/authhome.css">
@endsection

@section('content')
    @include('home.homelayout')
    <div class="logout">
        @auth
            <form action="/logout" method="GET">
                @csrf
                <input id="logout" type="submit" value="Logout">
            </form>
        @endauth    
    </div>
@endsection