<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoryController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class, 'guesthome']);
Route::get('/member', [HomeController::class, 'memberhome']);
Route::get('/admin', [HomeController::class, 'adminhome']);

Route::get('/manage-product', function () {
    return view('page/manageproduct');
});

Route::get('/signin', [AuthController::class, 'loginPage'])->name('login');
Route::post('/signin', [AuthController::class, 'login']);

Route::get('/signup', [AuthController::class, 'signupPage']);
Route::post('/signup', [AuthController::class, 'signup']);

Route::get('/logout', [AuthController::Class, 'logout']);

Route::group(['middleware' => ['adminsecurity']], function(){
    Route::get('/addcategory', [ProductController::class, 'addcategory']);
    Route::post('/category', [CategoryController::class, 'insertCategory']);
    Route::delete('/category/{id}', [CategoryController::class, 'deleteCategory']);

    Route::get('/addproduct', [ProductController::class, 'addproduct']);
    Route::post('/product', [ProductController::class, 'insertProduct']);
    Route::get('/updateproduct', [ProductController::class, 'editproduct']);
    Route::patch('/product', [ProductController::class, 'updateProduct']);
    Route::delete('/product/{id}', [ProductController::class, 'deleteProduct']);
});

Route::group(['middleware' => ['membersecurity']], function(){
    Route::get('/addtocart/{id}', [ProductController::class, 'addtocart'])->name('addtocart');
    Route::get('/shopping-cart', [ProductController::class, 'cart'])->name('shoppingCart');
    Route::get('/checkout', [ProductController::class, 'checkout'])->name('checkout');
    Route::post('/checkout', [ProductController::class, 'finalcheckout'])->name('finalcheckout');
});
Route::get('/products', [ProductController::class, 'getAll']);
Route::get('detail/{id}', [ProductController::class, 'detail']);


Route::get('/about', function(){
    return view('page/about');
});

Route::get('user', [UserController::class, 'user'])->name('user.edit');
Route::put('userupdate', [UserController::class, 'userUpdate'])->name('user.update');