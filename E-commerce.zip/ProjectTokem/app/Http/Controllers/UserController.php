<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    public function user(){
        return view('page.profile');
    }
    public function userUpdate(Request $request){
        $request->validate([
            'name' => ['string', 'required'],
            'email' => ['string', 'required'],
            'address' => ['string', 'required'],
            'phone' => ['string', 'required'],
        ]);
        auth()->user()->update([
            'name' => $request->name,
            'email' => $request->email,
            'address' => $request->address,
            'phone' => $request->phone,
        ]);
        return back()->with('message', 'Your profile has been updated');
    }
}
