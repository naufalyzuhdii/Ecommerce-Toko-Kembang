<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Session;

class ProductController extends Controller
{
    public function getAll(){
        $products = Product::latest();
        if(request('search')){
            $products->where('name', 'like', '%'. request('search'). '%');
        }
        // $products = Product::all();
        return view('page/products', [
            "products" => $products->paginate(8)
        ]);
    }
    public function detail($id){
        $product = Product::find($id);
        return view('page/productdetail', ['product' => $product]);
    }
    public function addcategory(){
        $products = Product::all();
        $categories = Category::all();
        return view('page/addcategory', compact('products', 'categories'));
    }
    public function addproduct(){
        $products = Product::all();
        $categories = Category::all();
        return view('page/addproduct', compact('products', 'categories'));
    }
    public function editproduct(){
        $products = Product::all();
        $categories = Category::all();
        return view('page/updateproduct', compact('products', 'categories'));
    }
    
    public function insertProduct(Request $request){
        $rules = [
            'name' => 'required|unique:products',
            'description' => 'required',
            'price' => 'required',
            'image' => 'required|image',
            'stock' => 'required|min:1'
        ];
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            return back()->withErrors($validator);
        }
        $product = new Product();
        $product->name = $request->name;
        $product->description = $request->description;
        $product->price = $request->price;
        $product->stock = $request->stock;
        $product->category_id = $request->category;

        $file = $request->file('image');
        $fileName = time().$file->getClientOriginalName();
        Storage::putFileAs('public/images', $file, $fileName);

        $product->image = 'images/'.$fileName;

        $product->save();

        return redirect('/products');
    }
    public function updateProduct(Request $request){
        $product = Product::find($request->id);
        $product->name = $request->name!=null?$request->name : $product->name;
        $product->description = $request->description!=null?$request->description : $product->description;
        $product->price = $request->price!=null?$request->price : $product->price;
        $product->category_id = $request->category!=null?$request->category : $product->category_id;
        $file = $request->file('image');
        if(isset($file)){
            $fileName = time().$file->getClientOrOriginalName();
            Storage::delete('public/'. $product->image);
            Storage::putfileAs('publc/images', $file, $fileName);
            $product->image = 'public/'.$fileName;
        }
        $product->save();
        return redirect('/products');
    }
    public function deleteProduct($id){
        $product = Product::find($id);
        if(isset($product)){
            Storage::delete('public/'. $product->image);
            $product->delete();
        }
        return redirect('/products');
    }
    public function addtocart(Request $request, $id){
        $product = Product::find($id);
        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Cart($oldCart);
        $cart->add($product, $product->id);
        $request->session()->put('cart', $cart);
        return redirect('/products');
    }
    public function cart(){
        if(!Session::has('cart')){
            return view('page/cart');
        }
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        return view('page/cart', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }
    public function checkout(){
        if(!Session::has('cart')){
            return view('page/cart');
        }
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $total = $cart->totalPrice;
        return view('page/checkout', ['total' => $total]);
    }
    public function finalcheckout(Request $request){
        if(!Session::has('cart')){
            return redirect()->route('checkout');
        }
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        // $order = new Order();
        // $order->cart = serialize($cart);
        // $order->payment_id = $charge->id;
        // Auth::user()->orders()->save($order);

        Session::forget('cart');
        return redirect('/products')->with('success', 'Checkout success!');
    }
}