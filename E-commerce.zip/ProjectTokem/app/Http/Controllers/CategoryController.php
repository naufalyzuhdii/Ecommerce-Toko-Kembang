<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;


class CategoryController extends Controller
{
    public function insertCategory(Request $request){
        $category = new Category();
        $category->name = $request->name;
        $category->save();
        return redirect('/addcategory');
    }
    public function updateCategory(Request $request){
        $category = Category::find($request->id);
        $category->name = $request->name!=null?$request->name : $category->name;
        $category->save();
        return redirect('/products');
    }
    public function deleteCategory($id){
        $category = Category::find($id);
        $category->delete();
        return redirect('/products');
    }
}
