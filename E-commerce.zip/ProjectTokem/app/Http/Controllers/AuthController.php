<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Session;

class AuthController extends Controller
{
    public function loginPage(){
        return view('login.signin');
    }
    public function login(Request $request){
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required']
        ]);
        if($request->remember){
            Cookie::queue('mycookie', $request->email, 15);
        }
        else{
            Cookie::queue(Cookie::forget('mycookie'));
        }
        if(Auth::attempt($credentials, true)){
            Session::put('mysession', Auth::user()->name);
            if(Auth::user()->role == 'member') return redirect('/member');
            else if(Auth::user()->role == 'admin') return redirect('/admin');
            return redirect('/');
        }
        return back()->withErrors("Not Registered", "signIn");
    }

    public function signupPage(){
        return view('login.signup');
    }
    public function signup(Request $request){
        $validator = validator($request->all());

        if ($validator->fails()) {
            return redirect()
                        ->back()
                        ->withErrors($validator)
                        ->withInput();
        }
        User::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            'address' => $request['address'],
            'phone' => $request['phone']
        ]);
        return redirect()->route('login');
    }
    // public function signup(Request $request){
    //     $request->validate([
    //         'name' => 'required',
    //         'email' => 'required|email|unique:users',
    //         'password' => 'required|min:6',
    //         'address' => 'required',
    //         'phone' => 'required',
    //     ]);
    //     $data = $request->all();
    //     $check = $this->create($data);
    //     return redirect('/member')->withSuccess('You have signed up!');
    // }
    // public function create(array $data){
    //     return User::create([
    //         'name' => $data['name'],
    //         'email' => $data['email'],
    //         'password' => Hash::make($data['password']),
    //         'address' => $data['address'],
    //         'phone' => $data['phone']
    //     ]);
    // }

    public function logout(){
        Auth::logout();
        Session::forget('mysession');
        return redirect('/signin');
    }
}